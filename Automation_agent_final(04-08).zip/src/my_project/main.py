import sys
from my_project.crew import AutomationAgent
from datetime import datetime

def run():
    """
    Run the crew.
    """
    inputs = {
        'query': "Write an email to sh78793509@gmail.com and ask him 'where is the file kept. and with subject 'Testing Email' 'Also add this line 'hdusbfh'. Also tell him the benefits of Technology.",
        'file_path':None,#'S:\AffyCloud\Crew AI\Automation_agent\PhotoRoom-20230811_172454.png',  # Optional file path for attachment
        'csv_file':None ,#'S:\AffyCloud\Crew AI\Automation_agent\Book1.csv',  # Optional CSV file path for email
        'date': datetime.now().strftime('%Y-%m-%d')
    }
    AutomationAgent().crew().kickoff(inputs=inputs)





